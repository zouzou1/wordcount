import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.Map.Entry;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;


public class Main extends JFrame 
{
	//��Ƶ�������ť
	private static JButton highFrequencyButton; 
	//ͳ��ָ�����ʸ�����ť
	private static JButton wordCountButton;
	//��Ƶд���ļ���ť
	private static JButton printFile; 
	//����������ͳ�ư�ť
	private static JButton lineWordCount; 
	//����
	private static JLabel input;
	//���
	private static JFrame statistics; 
	//�ļ���
	private static JTextField file2; 
	private static JLabel file ;
	
	public static FileReader fr;
	static BufferedReader br;
	//����
	static int rowNumber=0; 
	//������
	static int wordNumber=0;
	//ͳ����������������ʱ��
	static long time;
	/**��ʼ����½����*/
	public Main ()
	{ 
		//��������
   	    Font font =new Font("����", Font.BOLD, 20); 
   	    statistics=new JFrame("Ӣ���ı�ͳ�Ʒ���");
		statistics.setSize(600, 800);
		input=new JLabel();
		
		
		file=new JLabel("������Ҫ��ѯ���ļ���:");
		file.setBounds(100, 50, 400, 50);
		
		highFrequencyButton=new JButton("�����Ƶ��ߵ�ǰN������");    
		highFrequencyButton.setBounds(100, 250, 400, 50);
		highFrequencyButton.setFont(font);
		
		wordCountButton=new JButton("ͳ�����뵥�ʵĴ�Ƶ");
		wordCountButton.setBounds(100, 350, 400, 50);
		wordCountButton.setFont(font);

		printFile=new JButton("��Ƶд���ļ�");
		printFile.setBounds(100, 450, 400, 50);
		printFile.setFont(font);
		
		lineWordCount=new JButton("ͳ������������");
		lineWordCount.setBounds(100, 550, 400, 50);
		lineWordCount.setFont(font);

		//�����ı���
		file2 = new JTextField();
		file2.setBounds(100, 150, 400, 40);
		
		input.add(file);
		input.add(file2);
	 
		input.add(highFrequencyButton);
		input.add(wordCountButton);
		input.add(printFile);
		input.add(lineWordCount);
		
		statistics.add(input);
		statistics.setVisible(true);
		statistics.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		statistics.setLocation(300,400);

	}
	/**��ָ���ļ����뵥�ʲ�ͳ�ƴ�Ƶ*/
    static void FileName(final Map<String, Integer> map) throws IOException
    {
		String file=file2.getText();	
		if (file.isEmpty())
		{
			JOptionPane.showMessageDialog(null, "�������ļ�����","��",JOptionPane.INFORMATION_MESSAGE);
		}
		else 
		{
			try 
			{
				fr= new FileReader(file);
			} 
			catch (FileNotFoundException e2) 
			{
				e2.printStackTrace();
			}	
	    	BufferedReader b = new BufferedReader(fr);
	            String value= b.readLine();
	            long start = System.currentTimeMillis();
	            rowNumber=0;
	            while (value!= null) 
	            {
	            	//����������
	            	String[] words = value.split("[������.��,\"!--;:?\'\\] ]"); 
	            	for (int i = 0; i < words.length; i++) 
	            	{
	            		//����д��ĸת��ΪСд��ĸ
	                      String key = words[i].toLowerCase();
	                		if (key.length() > 0) 
	                		{
	                      		if (!map.containsKey(key)) 
	                      		{
	                      			wordNumber++;
	                          		map.put(key, 1);
	                          		} 
	                      		else 
	                      		{ 
	                      			int k = map.get(key)+1;// ������ǵ�һ�γ��֣��Ͱ�kֵ++
	                                map.put(key, k);
	                          		}
	                      		}
	                  		} 
	                value = b.readLine();
	                rowNumber++;
	            }
	            long end=System.currentTimeMillis();
	            time=end-start;
		}   
	}
	public static void main(String[] args)
	{
		Map<String, Integer> map = new TreeMap<String, Integer>();
	    Main main = new Main();
	    /**�򿪲鿴ǰN����Ƶ�ʽ���*/
		highFrequencyButton.addActionListener(new ActionListener()
		{
        public void actionPerformed(ActionEvent event)
        {
           if (event.getSource()==highFrequencyButton)
           {  
			   try 
			   {
				FileName(map);
			    } 
			   catch (IOException e) 
			   {
				// TODO Auto-generated catch block
				e.printStackTrace();
			   }	 	    
        	   new HFW(map);
           }
        }
     });
		 /**�򿪲�ѯָ�����ʴ�Ƶ����*/
		wordCountButton.addActionListener(new ActionListener()
		{
        public void actionPerformed(ActionEvent event)
        {
           if (event.getSource()==wordCountButton)
           {
        	   try 
        	   {
				FileName(map);
			   } 
        	  catch (IOException e) 
        	   {
				// TODO Auto-generated catch block
				e.printStackTrace();
			   }
        	 
        	   new WCS(map);  
           }
        }
     });
		 
		 /**ִ�д�Ƶд���ļ�����*/
		printFile.addActionListener(new ActionListener()
		{
        public void actionPerformed(ActionEvent event)
        {
           if (event.getSource()==printFile)
           {
        	   try 
        	   {
				FileName(map);
			    } 
        	   catch (IOException e) 
        	   {
				// TODO Auto-generated catch block
				e.printStackTrace();
			    }      
        	PTF rs = new PTF(); 
			try 
			{
				rs.PrintToF(map);
			} 
			catch (IOException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			JOptionPane.showMessageDialog(null, "д���ļ��ɹ�����result.txt�в鿴��","��ʾ",JOptionPane.INFORMATION_MESSAGE);	   
           }
        }
     });
		 /**�鿴�ı������͵�����*/
		lineWordCount.addActionListener(new ActionListener()
		{
        public void actionPerformed(ActionEvent event)
        {
           if (event.getSource()==lineWordCount)
           {
        	   try 
        	   {
				FileName(map);
			   } 
        	   catch (IOException e) 
        	   {
				// TODO Auto-generated catch block
				e.printStackTrace();
			    }
        	   JOptionPane.showMessageDialog(null,"Lines��"+rowNumber+"\n"+"WordsNumber��"+wordNumber+"\n"+"Time��"+time+"ms","Result",JOptionPane.INFORMATION_MESSAGE);
           }
        }
     });
	  
	}
}
